var d = new Date();
var weekday = new Array(7);
weekday[0]=  "Sun";
weekday[1] = "Mon";
weekday[2] = "Tue";
weekday[3] = "Wed";
weekday[4] = "Thu";
weekday[5] = "Fri";
weekday[6] = "Sat";
var month = new Array(12);
month[0] = "Jan";
month[1] = "Feb";
month[2] = "Mar";
month[3] = "Apr";
month[4] = "May";
month[5] = "Jun";
month[6] = "Jul";
month[7] = "Aug";
month[8] = "Sep";
month[9] = "Oct";
month[10] = "Nov";
month[11] = "Dec";

var day = d.getMonth() + 1 + '/' + (d.getDate() + 1) + '/' + d.getFullYear();
console.log(day);

var request = require("request");
var cheerio = require("cheerio");

request({
    uri: 'http://www.opentable.com/avenida-minnetonka?m=46&p=2&d=5/4/2016%207:00:00%20PM&r=190084&t=rest&rp=opentables.aspx&rid=190084'
}, function (error, response, body) {
    var $ = cheerio.load(body);
    var total = 0;
    $('.dtp-results-times li').each(function () {
        if ($(this).text().length > 1) {
            total += 1;
        }
    });
    console.log(total);
});
